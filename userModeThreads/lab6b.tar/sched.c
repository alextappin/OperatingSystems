#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "sched.h"

// use a 1M stack
#define STACK_SIZE  (1024*1024)

typedef struct thread_s
{
    unsigned long sp;
    unsigned long fp;
    long *stack;
    void *(*start_func)(void *arg);
    void *arg;
} thread_t;

thread_t *Current_Thread;

//*************************************
// This function can be used for adding debug statements to your code.
// Debug statements can then be turned on/off with the Do_Debug flag.
static int Do_Debug = 0;
static void debug_print(const char *fmt, ...)
{
    if (!Do_Debug) return;

    va_list args;
    va_start(args, fmt);

    vfprintf(stderr, fmt, args);
    va_end(args);
}
//*************************************
void mythread_init()
{
    // Create TCB for whoever is initing me
    Current_Thread = (thread_t *)malloc(sizeof(thread_t));
    assert(Current_Thread != NULL);

    memset(Current_Thread, 0, sizeof(thread_t));

    Current_Thread->sp = 0;
    Current_Thread->fp = 0;
    Current_Thread->stack = NULL;
    Current_Thread->start_func = NULL;
    Current_Thread->arg = NULL;
}
// //*************************************
// Function that gets called on thread startup. It calls the main thread
// function and then stops the thread.
static void start_thread_func()
{
    void *result;
    result = Current_Thread->start_func(Current_Thread->arg);

    mythread_exit(result);
}

// //*************************************
// Equivalent of pthread_create
unsigned long mythread_create( void *(*func)(void *arg), void *arg)
{
    long *mem;
    thread_t *thread;

    // allocate the thread control block
    thread = (thread_t *)malloc(sizeof(thread_t));
    assert(thread != NULL);

    memset(thread, 0, sizeof(thread_t));

    // Allocate space for the stack
    thread->stack = (long *)malloc(STACK_SIZE*sizeof(long));

    // Remember the user's thread function and argument
    thread->start_func = func;
    thread->arg = arg;

    // Initialize the stack. Pretend we made a call to yield 
    // from the beginning of start_thread_func
    //
    // NOTE: The following code, even though written in C is machine specific
    mem = thread->stack;

    mem[STACK_SIZE-1] = (long)start_thread_func;        // return addr
    mem[STACK_SIZE-2] = (long)&mem[STACK_SIZE-2];       // frame ptr
    thread->fp = (long)&mem[STACK_SIZE-2];              // save FP
    thread->sp = (long)&mem[STACK_SIZE-2];              // save SP

    // a call to yield will now run this thread
    return 0;   // should return thread_id
}

// //*************************************
// Threads call this to yield the CPU
void mythread_yield()
{
    unsigned long reg;

    debug_print("Thread is yielding\n");
    // save FP, SP and queue current thread in ready queue
    __asm__ volatile("movq %%rbp, %0" : "=m" (reg) : :);
    Current_Thread->fp = reg;
    __asm__ volatile("movq %%rsp, %0" : "=m" (reg) : :);
    Current_Thread->sp = reg;

    // Get the next thread
    // Current_Thread = pick_a_thread,any_thread();

    debug_print("Thread is running\n");

    // restore the SP, FP
    reg = Current_Thread->sp;
    __asm__ volatile("movq %0, %%rsp" : : "m" (reg) :);

    reg = Current_Thread->fp;
    __asm__ volatile("movq %0, %%rbp" : : "m" (reg) :);

    // return to next thread
    return;
}
//*************************************************
// Terminate a thread
void mythread_exit(void *result)
{
    debug_print("Thread is exiting\n");

    // clean up thread data structures

    Current_Thread = NULL;
    mythread_yield();
}
// **********************************
// Wait for a thread
void mythread_join(unsigned long thread_id, void **result)
{
}
void mythread_detach(unsigned long thread_id)
{
}
void mythread_cleanup()
{
}

